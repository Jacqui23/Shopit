package com.stdev.shopit.data.util

object Constants {
    const val USER_IS_LOGGED_IN = "USER_IS_LOGGED_IN"
    const val IS_FIRST_APP_LAUNCH = "IS_FIRST_APP_LAUNCH"
}