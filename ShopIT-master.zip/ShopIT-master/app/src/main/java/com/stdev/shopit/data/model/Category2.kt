package com.stdev.shopit.data.model

data class Category2(
    var id : Int,
    var category : String
)