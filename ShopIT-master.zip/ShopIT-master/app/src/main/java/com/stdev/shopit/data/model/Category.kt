package com.stdev.shopit.data.model


import com.google.gson.annotations.SerializedName

class Category : ArrayList<String>()