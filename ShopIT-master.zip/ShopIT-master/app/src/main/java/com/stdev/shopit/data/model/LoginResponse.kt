package com.stdev.shopit.data.model

data class LoginResponse(
    val token: String,
)
