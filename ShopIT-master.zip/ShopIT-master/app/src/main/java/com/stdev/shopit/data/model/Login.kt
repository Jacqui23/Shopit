package com.stdev.shopit.data.model

data class Login(
    val username: String,
    val password: String
)
